import React, { useState } from 'react';

const timetable = [
  { time: "7:00 – 8:00 PM", tasks: ["Q1", "Q2", "Q3", "Q4"] },
  { time: "8:10 – 9:10 PM", tasks: ["Q5", "Q6", "Q7", "Q8"] },
  { time: "9:20 – 10:20 PM", tasks: ["Q9", "Q10", "Q11", "Q12"] },
  { time: "10:30 – 11:00 PM", tasks: ["Q13", "Q14", "Q15", "Q16"] },
  { time: "5:00 – 6:00 AM", tasks: ["Q17", "Q18", "Q19", "Q20"] },
  { time: "6:00 – 7:00 AM", tasks: ["Q21", "Q22", "Q23", "Q24"] },
  { time: "7:00 – 8:00 AM", tasks: ["Q25", "Q26", "Q27", "Q28"] },
  { time: "8:00 – 9:00 AM", tasks: ["Q29", "Q30", "Q31", "Q32"] },
  { time: "9:30 – 10:30 AM", tasks: ["Q33", "Q34", "Q35", "Q36"] },
  { time: "10:30 – 11:30 AM", tasks: ["Q37", "Q38", "Q39", "Q40"] },
  { time: "11:30 – 12:30 PM", tasks: ["Q41", "Q42", "Q43", "Q44"] },
  { time: "1:30 – 2:30 PM", tasks: ["Q45", "Q46", "Q47", "Q48"] },
  { time: "2:30 – 3:30 PM", tasks: ["Q49", "Q50"] },
  { time: "4:00 – 5:00 PM", tasks: ["Review Q1–Q25"] },
  { time: "5:00 – 6:00 PM", tasks: ["Review Q26–Q50"] },
  { time: "6:00 – 7:00 PM", tasks: ["Doubt-solving", "Confident Qs recap"] }
];

export default function StudyTimetable() {
  const [checkedItems, setCheckedItems] = useState({});

  const handleCheckboxChange = (task) => {
    setCheckedItems({
      ...checkedItems,
      [task]: !checkedItems[task],
    });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto text-center">
      <h1 className="text-3xl font-bold mb-6">📘 Study Timetable Tracker</h1>
      <div className="grid gap-4">
        {timetable.map((slot, index) => (
          <div key={index} className="p-4 border rounded-xl shadow-md bg-white text-left">
            <h2 className="font-semibold text-xl mb-2">⏰ {slot.time}</h2>
            <ul className="pl-4">
              {slot.tasks.map((task, i) => (
                <li key={i} className="flex items-center gap-2 mb-1">
                  <input
                    type="checkbox"
                    checked={checkedItems[task] || false}
                    onChange={() => handleCheckboxChange(task)}
                  />
                  <span className={checkedItems[task] ? "line-through text-gray-500" : ""}>{task}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
